/*
 *
 */
package to.tetramorph.starbase;
import static java.lang.System.*;
import java.util.*;
import java.io.*;
import to.tetramorph.starbase.lib.Home;
import to.tetramorph.util.CSVReader;
import to.tetramorph.util.CSVWriter;
/**
 * 占星術辞典ファイルをロードして、ハッシュ式で管理する。
 * 今のところ、辞書の１ノードは、「タイトルと意味」を「キーワード」で結びつけられたもの。
 * キーワード、タイトル、意味の３つのフィールドをもつCSVファイルから読みこむ。
 */
class AstroDict {
  Map<String,String[]>map = new HashMap<String,String[]>();
  //データの順番を保管するためのもの
  List<String>lineList = new ArrayList<String>();
  /**
   * 占星術辞書オブジェクトを作成する。引数fileにはCSV形式の辞書ファイルを指定する。
   * 辞書の各フィールドは1番目キーワード、2番目タイトル、3番目が解説。
   */
  File file;
  public AstroDict(File file) {
    this.file = file;
    CSVReader stream = null;
    try {
      stream = new CSVReader(file,"sjis");
      while( stream.ready() ) {
        String [] buf = stream.readCSV();
        String [] value = new String[2];
        for(int i=0; i<value.length; i++) value[i]="";
        if(buf.length >= 2) value[0] = buf[1];
        if(buf.length >= 3) value[1] = buf[2];
        //String [] values = { buf[1],buf[2] };
        map.put(buf[0],value);
        lineList.add(buf[0]);
      }
    } catch( IOException e ) {
      out.println(e);
    } finally {
      try { stream.close(); } catch(Exception e) { }
    }
  }
  
  public void save() {
    CSVWriter stream = null;
    try {
      stream = new CSVWriter(file,"sjis");
      for(int i=0; i<lineList.size(); i++) {
        String key = lineList.get(i);
        String [] value = map.get(key);
        String [] temp = { key,value[0],value[1] };
        stream.writeCSV(temp);
      }
    }catch(IOException e) {
      out.println(e);
    }finally {
      try { stream.close(); } catch(Exception e) { }
    }
  }
  /**
   * "h1_lib_sun_6"などという値が、keyに与えられ呼び出されると、この条件に該当するいく
   * つかのキーを見つけ出してかえす。この例だとh1,lib,h1_lib,lib_sun,sun_6などが候補の
   * 対象となり、それらのキーに対応するデータが存在するなら、そのキーが返却ﾘｽﾄに加わる。
   * ｾﾊﾟﾚｰﾀ("_")で与えられたキー文字列をトークンに分解し、それらを2進数の桁のように見
   * 立てる。"h1","lib","sun","6"に分解されたら、それは4bitとみなす。4bitの最大値は二
   * 進数で1111で10進数だと15。15から1まで2進数でデクリメントしていき、各桁のbitが1に
   * なっているキーワードを取り出して連結する。
   * 今0110なら、"lib"と"sun"が取り出され。"lib_sun"というキーワードが生成され、
   * ハッシュに登録されているか確認して、登録されているなら候補の一つとしてリストに
   * 保管される。この過程を繰り返し、14パターンを検査する。
   * その後候補になったキーワードリストを配列に入れ直して返す。
   * 注意しなければならないのは、すべての組合せのパターン列挙ではないということ。
   * "lib_sun"はありえても、"sun_lib"というパターンは検査されない。
   * 元になるキーに含まれる単語の出現順序は最後まで意味を持ち続けている。
   * 全パターンを網羅することも考えたが、そのアルゴリズムが簡単そうでいて、なかなか
   * 難しい上、項数がふえるとずいぶんと多くのパターンが検査が必要になるので妥協した。
   */
  public String[] getKeys(String key) {
    String [] tokens = key.split("_");
    
    List<String> keys = new ArrayList<String>();
    int max = (int)Math.pow(2,tokens.length) - 1;
    for(; max>0; max--) {
      StringBuffer sb = new StringBuffer();
      String b = "00000".concat(Integer.toString(max,2));
      b = b.substring(b.length()-tokens.length);
      char bin[] = b.toCharArray();
      for(int i=0; i<bin.length; i++) {
        if(bin[i] == '1') sb.append(tokens[i]+"_");
      }
      sb.deleteCharAt(sb.length()-1);
      String k = sb.toString();
      //out.println("k = " + k);
      if(map.containsKey(k)) keys.add(k);
    }
    String [] array = new String[keys.size()];
    for(int i=0; i<array.length; i++) array[i] = keys.get(i);
    return array;
  }
  /**
   * キーに対応する値を返す。
   * 配列は0番目の要素は「タイトル」。1番目は「意味」
   */
  public String [] getValue(String key) {
    return map.get(key);
  }
  
  public void setValue(String key,String [] value) {
    map.put(key,value);
  }

  public static void main(String args[]) {
    File file = new File(Home.dir,"astro_dict.csv");
    AstroDict astroDict = new AstroDict(file);
    String [] temp = astroDict.getKeys("lib_sun");
    out.println("-----------------------------");
    for(int i=0; i<temp.length; i++) {
      out.println("keys = " + temp[i]);
    }
  }
}

