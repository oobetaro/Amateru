/*
 * AmateruSiteAction.java
 *
 * Created on 2008/11/21, 15:18
 *
 */

package to.tetramorph.starbase;

import java.awt.Desktop;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import to.tetramorph.starbase.lib.Home;

/**
 * ヘルプメニューの中の「アマテルのホームページ」のメニューアクション。
 * @author 大澤義鷹
 */
public class AmateruSiteAction extends AbstractAction {
    private Frame owner;
    
    /**  
     * AmateruSiteAction オブジェクトを作成する 
     */
    public AmateruSiteAction( Frame owner ) {
        this.owner = owner;
    }
    public void actionPerformed( ActionEvent evt ) {
        if ( Desktop.isDesktopSupported() ) {
            try {
                Desktop.getDesktop().browse( 
                    Home.getSupportURL().toURI() );
            } catch ( Exception e ) {
                error("ブラウザが使用できません。\n" + e.toString() );
            }
        } else
            error( "お使いのプラットホームでこの機能はサポートされていません。");        
    }

    private void error( String msg ) {
        JOptionPane.showMessageDialog( owner, msg, "ブラウザの起動に失敗",
                                                    JOptionPane.ERROR_MESSAGE );
    }
    
}
