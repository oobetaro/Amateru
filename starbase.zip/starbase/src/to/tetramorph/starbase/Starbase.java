/*
 * Starbase.java
 *
 * Created on 2007/11/16, 8:36
 *
 */

package to.tetramorph.starbase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jnlp.SingleInstanceListener;
import javax.jnlp.SingleInstanceService;
import to.tetramorph.starbase.lib.Home;
import to.tetramorph.util.Sleep;
import to.tetramorph.util.StopWatch;

/**
 * エントリー。二重起動の抑止機能、DBの起動と初期設定、
 * およびSwing全体の外観プロパティの設定のち、Mainクラス作成しセットアップする。
 * 時間がかかる処理なのでスプラッシュウィンドウを表示し、経過状況の表示を行い
 * ながら処理する。
 * @author 大澤義鷹
 */
class Starbase {
    //
    private Starbase() {}
    private static int MUTEX_PORT = 12399;
    private static SingleInstanceListener sil = null;
    private static SingleInstanceService sis = null;
    private static Main main;

    //シャットダウン
    private static void shutdown( String msg ) {
        SplashWindow.getInstance().setError(msg);
        System.out.println( msg );
        System.exit(0);
    }


    /**
     * データベースに接続できるか検査。成功すればtrueを返す。
     */
    private static boolean isRunningHsqldb() {
        boolean enabled = false;
        try {
            String driverURL = "jdbc:hsqldb:hsql://localhost";
            String pw = Config.usr.getProperty("db.admin.pw","");
            System.out.println("pw = " + pw);
            Connection con = DriverManager.getConnection( driverURL,"sa", pw );
            con.close();
            enabled = true;
        } catch ( Exception e ) {
        }
        return enabled;
    }


    //HSQLDBを起動
    private static void startHsqldb() {
        String dbfile = "file:" + Home.database.toURI().getPath();
        // 行末の""はHSQLDBに別名を与える際に使用するが与えないので空。
        String [] options = { "-database.0", dbfile, "-dbname.0", "" };
        System.out.println("DBを起動 db_file = " + dbfile);
        try {
            org.hsqldb.Server.main( options );
        } catch ( Exception e ) {
            SplashWindow.getInstance().setError("DBの起動に失敗");
        }
        /*
         * 空のパスワードでログインできたら、まだDBにテーブルは作成されていないと
         * みなして作成する。ログインできなければ、すでににパスワードも設定され
         * テーブルも作成されているとみなす。
         */
        Connection con = null;
        try {
            String driverURL = "jdbc:hsqldb:hsql://localhost";
            //PWなしでログイン
            con = DriverManager.getConnection( driverURL, "sa", "" );

            //空PWでログインできなければ以下の処理はスキップされる

            String pw = Config.usr.getProperty( "db.admin.pw", "" );
            if ( pw.isEmpty() ) throw
                new IllegalStateException("adminパスワードが未設定");
            String sql = String.format(
                "ALTER USER \"sa\" SET PASSWORD \"%s\"",pw);
            Statement stmt = con.createStatement();
            stmt.execute(sql);
            //ゲストアカウントの作成とプロパティ表の作成
            DBFactory.createTable("/resources/CreateTable0.txt",con);
            //メインとなるテーブルの作成とguestアカウントへ読み取り権限を与える
            DBFactory.createTable("/resources/CreateTable.txt",con);
            //ストアドプロシージャの登録
            DBFactory.createTable("/resources/CreateTable1.txt",con);
            System.out.println("DBにテーブル作成");
        } catch ( SQLException e ) {
            if ( ! e.getMessage().matches(".*Access is denied$") ) {
                Logger.getLogger( Starbase.class.getName() )
                        .log( Level.SEVERE, null, e );
            }
        } catch ( IllegalStateException e ) {
            Logger.getLogger( Starbase.class.getName() )
                    .log( Level.SEVERE, null, e );
        } finally {
            try { con.close(); } catch ( Exception e ) { }
        }
        SplashWindow.getInstance().addValue(20);
    }

    private static void startMutexServer() {
        if( sis == null ) {
            // シングルインスタンスサービスが動いていなければMutexServerを起動
            boolean ok = MutexServer.exec(MUTEX_PORT,main);
            if ( ! ok ) shutdown( "MutexServerの起動に失敗");
            // MutexServerのシャットダウン時の終了処理を登録
            Runtime.getRuntime().addShutdownHook( new Thread() {
                @Override
                public void run() {
                    MutexServer.abort( MUTEX_PORT );
                }
            });
        } else {
            // シングルインスタンスサービスが動いているときは
            // リスナを変更してそのまま使う
            sis.removeSingleInstanceListener( sil );
            sis.addSingleInstanceListener( main );
            Runtime.getRuntime().addShutdownHook(new Thread() {
                @Override
                public void run() {
                    sis.removeSingleInstanceListener( main );
                    System.out.println("SingleInstanceListenerを削除");
                }
            });
        }
    }

    // GUIを構成してアプリケーションをEDTでスタート
    private static void launch() {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                StopWatch.set();
                main = new Main();
                StopWatch.show("Mainパネル作成時間");
            }
        });
        startMutexServer();
        while ( main == null ) Sleep.exec(500);
        main.setup();
        MorningAccess.main( null );
        System.out.println("起動処理完了");
        SplashWindow.getInstance().dispose(); //スプラッシュウィンドウ消去
    }
    /**
     * Systemプロパティに"nodb"のキーが無いときは本番モードになり、プログラムの
     * 実行と共にDBの起動、終了と共にDBのシャットダウンが行われる。<BR>
     * キーがあるときはテストモードとなり、DBは事前に起動しておかなければならない。
     * DBの起動は時間がかかるため、テストランのたびに起動・停止をするのはつらいので
     * DBは常駐させておくやり方をする。テストモードの場合、アプリ終了時にDBのシャット
     * ダウンは行われない。
     * プロパティを指定しなかった場合は、暗黙のうちに本番モードとみなされる。
     *
     * もう一つ実行に必要なプロパティはスイスエフェメリスへのパスで、これを省略
     * することはできない。省略すればエラーでシャットダウンされる。
     * インストールされているディレクトリはプラットホームごとに異なるが、たとえ
     * ば次のように指定する。
     *
     * "-Dswe.path=C:\\users\\ephe"
     *
     * 多重起動を防ぐために、サーバースレッドを用意しており、そのポートは現在
     * 12399番に固定されている。最終的には変更可能にするが今は固定。
     */
    public static void exec( SingleInstanceService sis,
                              SingleInstanceListener sil )
                                                throws MalformedURLException {
        Starbase.sis = sis;
        Starbase.sil = sil;
        if(sis == null) {
            if ( MutexServer.isRunning( MUTEX_PORT ) )
                shutdown( "すでに動作中です。" );
        }

        //スイスエフェメリスのパス設定を確認
        if ( System.getProperty("swe.path") == null ) {
            shutdown("System property 'swe.path' not found.");
        }

        //DBや検索結果の窓を別フレームにするときはtrueをセット。
        //(この機能は削除したが、まだ残滓が残っているのでそのまま)
        System.setProperty( "SeparateMode", "false" );
        System.out.println( "nodb = " + System.getProperty("nodb") );

        //スプラッシュウィンドウを表示
        SplashWindow sw = SplashWindow.getInstance();
        sw.getJButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                SplashWindow.getInstance().dispose();
                System.exit(0);
            }
        });

        //JDBC をロードする
        try {
            Class.forName("org.hsqldb.jdbcDriver");
            sw.addValue(5);
        } catch ( ClassNotFoundException e ) {
            shutdown("JDBCのロードに失敗。");
        }

        if ( System.getProperty("nodb") != null ) { //外部DBモード

            System.out.println("外部DBモード");
            if ( ! isRunningHsqldb() )  //DBが動いていないなら
                shutdown("HSQLDBを外部で起動しておいてください。");

        } else { // 通常モード

            System.out.println("内部DBモード");
            if ( isRunningHsqldb() )  //DBが動いているなら
                shutdown(
                     "HSQLDBがすでに動作中なので停止させてから実行してください。");
            startHsqldb();
            sw.addValue(20);

        }
        DBFactory.getInstance();
        ChartPane.loadModules();
        sw.addValue(10);
        launch();
    }

}
