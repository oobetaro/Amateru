/*
 * TransitClip.java
 *
 * Created on 2008/01/05, 5:24
 *
 */

package to.tetramorph.starbase;

import to.tetramorph.starbase.lib.Transit;

/**
 * トランジットのコピペ用。
 * @author 大澤義鷹
 */
class TransitClip {
    static Transit transit = null;
}
