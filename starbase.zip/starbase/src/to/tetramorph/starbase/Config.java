/*
 * 2011/07/14
 */
package to.tetramorph.starbase;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import to.tetramorph.util.Preference;
import static java.lang.System.getProperty;
import static java.lang.System.setProperty;

/**
 * アマテルのプロパティを保管する。
 * Preferencesを使いたいところだが、テスト版と正式版のアマテルを２つインストールした
 * とき、どちらも共通のノードにアクセスしてしまうため、完全な分離ができなくなってしま
 * う。たとえば「あるキーが登録されていなければ初期化処理をする」といった場合、すでに
 * アマテルがインストールされていると、後からインストールした別のアマテルは判定を失敗
 * してしまう。<br><br>
 *
 * ファイルへのセーブとロードは、完全にマニュアルで行う。シャットダウンフックにかけて
 * おくとか過去にやったが、異常終了したとき挙動が怪しい。<br>
 * このクラスを使う前には一度load()を呼び出す。保存されたファイルがあるならロードされ
 * る。<br>
 * キーと値をセットしたら、save()を呼び出す。面倒だが仕方がない。
 *
 * システム用とユーザ用２つにわけてプロパティを管理することにしていたが、時間がたつと
 * どっちがどっちだか区別がつかなくなってくる。混乱のもとなので一つだけにする。
 * 気になることは、アマテルのIDやDBのパスワード。これらは例外的にレジストリにいれた
 * ほうがよいのかもしれない。
 *
 * @author 大澤義孝
 */
final class Config {
    /**
     * 使用ノードタイプやハウス分割法などユーザの設定保管用
     */
    public static Preference usr = new Preference();
//    /**
//     * GUIの状態保存などシステムよりの情報保管用。
//     */
//    public static Preference sys = new Preference();

    /**
     * @return 設定ファイルが存在しているときはtrueを返す。
     */
    public static boolean fileExists() {
        if ( getProperty("app.home","").isEmpty() )
            throw new IllegalStateException("app.homeが設定されていない");
        File dir = new File( getProperty("app.home"), "properties" );
        if ( ! dir.isDirectory() || ! dir.exists() )
            throw new IllegalStateException("プロパティ保管フォルダが無い");
        return new File( dir, "ConfigUsr.xml").exists();
    }

    /**
     * fileからprefにロードする。ファイルが存在しないならロード処理はしない。
     */
    private static void load( File file, Preference pref ) {
        if ( ! file.exists() ) return;
        FileInputStream stream = null;
        try {
            stream = new FileInputStream( file );
            pref.loadFromXML(stream);
        } catch ( IOException e ) {
            Logger.getLogger( Config.class.getName())
                    .log( Level.SEVERE, null, e );
        } finally {
            try { stream.close(); } catch ( Exception ex ) { }
        }
    }

    /**
     * 設定情報をapp.home/properties/ConfigSys.xmlとConfigUsr.xmlから読み込む。
     * @throws IllegalStateException System.getProperty("app.home")が設定されて
     * いない状態で呼び出されたとき。{app.home}/properties/フォルダが存在しないとき。
     */
    public static void load() {
        if ( getProperty("app.home","").isEmpty() )
            throw new IllegalStateException("app.homeが設定されていない");
        File dir = new File( getProperty("app.home"), "properties" );
        if ( ! dir.isDirectory() || ! dir.exists() )
            throw new IllegalStateException("プロパティ保管フォルダが無い");
        usr.clear();
        load( new File( dir, "ConfigUsr.xml" ), usr );
    }

    /**
     * prefをfileに書きこむ。prefが空なら書き込み処理はしない。
     */
    private static void save( File file, Preference pref ) {
        FileOutputStream stream = null;
        if ( pref.isEmpty() ) return;
        try {
            stream = new FileOutputStream( file );
            pref.storeToXML( stream, "【編集厳禁】アマテル設定ファイル　 http://tetramorph.to" );
        } catch ( IOException e ) {
            Logger.getLogger( Config.class.getName())
                    .log( Level.SEVERE, null , e );
        } finally {
            try { stream.close(); } catch ( Exception ex ) { }
        }
    }

    /**
     * 設定情報をapp.home/properties/ConfigUsr.xmlに書きだす。
     * @throws IllegalStateException System.getProperty("app.home")が設定されて
     * いない状態で呼び出されたとき。{app.home}/properties/フォルダが存在しないとき。
     */
    public static void save() {
        if ( getProperty("app.home","").isEmpty() )
            throw new IllegalStateException("app.homeが設定されていない");
        File dir = new File( getProperty("app.home"), "properties" );
        if ( ! dir.isDirectory() || ! dir.exists() )
            throw new IllegalStateException("プロパティ保管フォルダが無い");
        save( new File( dir, "ConfigUsr.xml" ), usr );
    }

    /**
     * usrから"DefaultTime"のキーで値を取り出す。値が入っていないときは、
     * "00:00:00"として値を登録し、またシステムプロパティにも同じ内容をセットする。
     * このキーは頻繁にあちこちから参照するので、専用のメソッドを用意した。
     * @return 登録されているデフォルトタイム
     */
    public static String getDefaultTime() {
        if ( usr.getProperty( "DefaultTime", "" ).isEmpty() ) {
             usr.put( "DefaultTime", "00:00:00" );
             setProperty( "DefaultTime", "00:00:00" );
        }
        return usr.getProperty( "DefaultTime" );
    }
    /**
     * デフォルトタイムをdataにセットする。
     * System.setProperty( time )も行われる。
     * @param time "00:00:00"などの時刻文字列
     */
    public static void setDefaultTime( String time ) {
        usr.put( "DefaultTime", time );
        System.setProperty( "DefaultTime", time );
    }

//    public static void main(String[] args) {
//        System.setProperty("app.home","C:/Users/ohsawa/Ama");
//        Config.load();
//        Config.usr.setBoolean("Goo", false);
//        Config.usr.setString("Hoge", "HogeHoge");
//        System.out.println( getDefaultTime() );
//        setDefaultTime("12:00:00");
//        Config.save();
//    }
}
