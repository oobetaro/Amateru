/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Conf.java
 *
 * Created on 2009/11/17, 0:58:04
 */

package to.tetramorph.starbase;

import java.util.prefs.Preferences;

/**
 * Configの代替品。
 * publicクラスではないので、starbase内でのみ使用される。他のパッケージから呼び
 * 出されることはない。
 * @author 大澤義鷹
 */
class Conf {
    static Preferences data = Preferences.userNodeForPackage(Conf.class);
    static Preferences system = Preferences.systemNodeForPackage(Conf.class);
    static final String DefaultTime = "DefaultTime";
    /**
     * dataから"DefaultTime"のキーで値を取り出す。値が入っていないときは、
     * "00:00:00"として値を登録し、またシステムプロパティにも同じ内容をセットする。
     * このキーは頻繁にあちこちから参照するので、専用のメソッドを用意した。
     * @return 登録されているデフォルトタイム
     */
    public static String getDefaultTime() {
        String dt = data.get(DefaultTime,"");
        if ( dt.isEmpty() ) {
            dt = "00:00:00";
            data.put(DefaultTime, dt);
            System.setProperty(DefaultTime, dt);
        }
        return dt;
    }
    /**
     * デフォルトタイムをdataにセットする。
     * System.setProperty( time )も行われる。
     * @param time "00:00:00"などの時刻文字列
     */
    public static void setDefaultTime(String time) {
        data.put(DefaultTime, time);
        System.setProperty(DefaultTime, time);
    }

    public static void main(String args[]) throws Exception {
        //Preferences p = data;
        Preferences p = system;
        for(String key : p.keys()) {
            String value = p.get(key, "unregist");
            System.out.println(key + "=" + value);
            p.remove(key);
        }
    }
}
