/*
 * Initiater.java
 *
 * Created on 2007/11/24, 10:09
 *
 */

package to.tetramorph.starbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.jnlp.ServiceManager;
import javax.jnlp.SingleInstanceListener;
import javax.jnlp.SingleInstanceService;
import javax.swing.UIManager;
import to.tetramorph.util.Preference;
import to.tetramorph.util.StopWatch;
import static java.lang.System.getProperty;
import static java.lang.System.setProperty;;
/**
 * アプリケーションのエントリーであり、ネット上のサーバから、モジュールや
 * 天文暦をDLしてインストールしたりアップデートする。
 * 起動時、つまりmain()を実行する際、いくつかのオプションを指定できる。
 * オプションはJVM起動時の-Dで、プロパティとして指定する。
 * 指定しなかった場合(普通はテスト時に指定するだけで実稼働時には指定しない)
 * デフォルトの値が採用される。
 * <pre>
 * キー
 * app.home
 *     アプリケーションのホームディレクトリ。
 *     デフォルトは"user.home/.Amateru"
 *     "c:/Document Setting/username/test"などと指定する。
 * app.home.name または javaws.app.home.name
 *     app.homeがnullのとき、このプロパティに
 *     "hoge"を指定すると、"user.home/hoge"がホームとなる。
 *    このプロパティを明示的に指定するのはテスト時のみ。
 *     app.homeがnullではないとき指定しても無視されるが、指定してはならない。
 *     JWSからこのプロパティを指定するときはjavaws.app.home.nameを使用する。
 *     そのようにしないとJWSのセキュリティの仕様上、デジタル認証に失敗する。
 *     つまりプロパティを指定したら、認証失敗と見当違いのエラーを報告されるため、
 *     非常に悩む事になるので注意。
 * app.smod
 * 　　サーチモジュールのjarを置くディレクトリでフルパスで指定する。
 *   　デフォルトはapp.home/searchmod
 * app.cmod
 * 　　チャートモジュールのjarを置くディレクトリでフルパスで指定する。
 *     デフォルトはapp.home/chartmod
 * app.offline
 * 　　これはキーのみで値は無視される。このキーを指定するとネットから
 *     関連ファイルのDLを行わない。デフォルトではDLを行う。
 * app.lib または javaws.app.lib
 *     天文暦や観測地データ、モジュールファイルをDLするサーバのURLを指定する。
 *     なおこのURLはサーバ上のディレクトリを指していなければならなず、ファイル
 *     ではない。つまり、URL文字列の末尾が"/"で終わるものが正しいのだが、それが
 *     無い場合末尾に"/"が追加される。
 *     これのプロパティは実行の際、必ず指定しなければならない。
 *     JWSから指定するときは、javaws.app.libを使用すること。
 * swe.path
 *     スイスエフェメリスの天文暦ファイルのディレクトリでフルパスで指定。
 *     デフォルトはapp.home/ehpe
 *     スイスエフェメリスの本来のデフォルトは/users/epheだが、このアプリケーション
 *     では、すべてapp.homeの下に置く仕様。
 * nodb
 *     キーのみで値は無視される。このキーを指定するとDBの起動を行わない。
 *     DBをあらかじめ別窓で起動しておき、アプリからの起動をキャンセルする。
 *     DBの起動はデータ登録件数が大きくなるにつれて遅くなり、3万件程度で何十秒も
 *     かかるようになる。それではデバッグがつらいのでこのスイッチがある。
 * </pre>
 *
 * IDE上でのデバッグ時には、app.offlineを指定して、ネットから切り離して、
 * app.smod,app.cmodでプロジェクトの./distディレクトリにパスを向ける。
 *
 * Windows2K環境下で,NetBeansでの起動オプションは次のように指定している。
 * (ただし改行せず一行に記述)
 *
 * <pre>
 * -ea
 * -Dcom.sun.management.jmxremote
 * -Dswe.path="c:\\users\\ephe"
 * -Dapp.home="c:\\Documents and Settings\\[accountName]\\test2"
 * -Dapp.cmod="c:\\sb\chartmod\\dist"
 * -Dapp.smod="c:\\sb\searchmod\\dist"
 * -Dapp.lib="http://tetramorph.to/amateru/app/applib/"
 * -Dapp.offline
 * -Dnodb
 * </pre>
 * .Amateruと同じ構造でtest2にもシステムファイルが置かれていて、
 * テストのときはtest2を指定している。
 * 本来は.Amateruを指定する。
 *  -Dapp.home="c:\Documents and Settings\[accountName]\.Amateru"
 * @author 大澤義鷹
 */
class Initiater {
    static String ERROR_MESSAGE1 =
        "を作成しようとしましたが<br>" +
        "すでに同名のディレクトリもしくはファイルが使用されています。<BR>" +
        "このような事態が発生することは予測の範囲でしたが、<BR>" +
        "宝くじ一等賞に当たるくらいまれなことであると思われ、<BR>" +
        "しかるべき回避措置をまだ用意してないです。<BR>" +
        "残念ですがシャットダウンします。</center></html>";

    static File homeFolder;    //.Amateruを指すFileオブジェクト
    static File propsFolder;
    private Initiater() {
    }

    static class ErrorDialog extends Thread {
        String mes;
        ErrorDialog(String mes) {
            this.mes = "<html>" + mes + "</html>";
        }
        @Override
        public void run() {
            JOptionPane.showMessageDialog(
                null,mes,"エラー",JOptionPane.ERROR_MESSAGE);
        }
    }

    static void errorDialog(String message) {
        ErrorDialog ed = new ErrorDialog(message);
        try {
            java.awt.EventQueue.invokeAndWait(ed);
        } catch (Exception ex) {
            Logger.getLogger(Initiater.class.getName())
                    .log(Level.SEVERE,null,ex);
        }
    }



    //
    static void saveProp(String propName,Properties prop) {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream( new File( propsFolder, propName ) );
            prop.storeToXML(fos,"","UTF-8");
        } catch ( IOException e ) {
            Logger.getLogger(Initiater.class.getName())
                    .log(Level.SEVERE,null,e);
        } finally {
            try { fos.close(); } catch ( Exception e) { }
        }
    }

    static Preference getProp(String propfile) {
        File propFile = new File( propsFolder, propfile);
        FileInputStream stream = null;
        Preference p = new Preference();
        if (! ( propFile.exists() && propFile.length() > 0 )) return p;
        try {
            stream = new FileInputStream(propFile);
            p.loadFromXML(stream);
        } catch (Exception e) {
            System.out.println( propfile + "の読込に失敗したが致命的ではない:"
                                         + propFile.getAbsolutePath());
        } finally {
            try { stream.close(); } catch(Exception ex) { }
        }
        return p;
    }

//    //確認してプロパティが存在するならレジストリにコピー
//    static void propcopy(String key,Properties p ) {
//        if ( p.getProperty(key) != null ) {
//            Conf.data.put(key, p.getProperty(key));
//        }
//    }
//
//    /**
//     * ファイルに保管するConfigを廃止し、Preferencesに置き換える。
//     * Preferencesにアマテルの年齢が登録されていなければ、旧方式から設定情報を
//     * 移行する処理をする。
//     */
//    static void setup_preferences() {
//
//        if ( Conf.system.getLong("AgeOfAmateru", -1) < 0 ) {
//            Conf.setDefaultTime("00:00:00");
//            Conf.data.putInt("CuspUnknownHouseSystem",1);
//            Conf.data.putInt("HouseSystemIndex",0);
//            Conf.data.putBoolean("PrioritizeSolar",true);
//            Conf.data.putBoolean("UseMeanNode",false);
//            Conf.data.putBoolean("UseMeanApogee",false);
//            Conf.data.putInt("DefaultTimeButtonIndex",1);
//            Conf.data.put("DefaultTransitPlace",
//                     "神奈川県・横浜市西区┃35.453962┃139.617206┃Asia/Tokyo");
//            Conf.data.put("app.topounit","10");
//            Conf.data.put("app.angleunit","10");
//            //
//            Conf.system.putLong("AgeOfAmateru", 0);
//            Conf.system.put("AMATERU_ID", "My name is AMATERU.");
//            Conf.system.put("db.admin.pw","amateru");
//            Conf.system.put("db.plugin.pw","plugin");
//
//            Preference s = getProp("System.properties");
//            Conf.system.putLong("AgeOfAmateru", s.getLong("AgeOfAmateru",0L));
//            String id = s.getProperty("AMATERU_ID","My name is AMATERU.");
//            Conf.system.put("AMATERU_ID", id);
//
//            Preference u = getProp("Config.properties");
//            propcopy("DefaultTime",u);
//            propcopy("CuspUnknownHouseSystem",u);
//            propcopy("HouseSystemIndex",u);
//            propcopy("PrioritizeSolar",u);
//            propcopy("UseMeanNode",u);
//            propcopy("UseMeanApogee",u);
//            propcopy("DefaultTimeButtonIndex",u);
//            propcopy("DefaultTransitPlace",u);
//            propcopy("app.topounit",u);
//            propcopy("app.angleunit",u);
//        }
//        setProperty("DefaultTime",Conf.getDefaultTime());
//        setProperty("app.topounit",Conf.data.get("app.topounit","10"));
//        setProperty("app.angleunit",Conf.data.get("app.angleunit","10"));
//
//        String cmod = getProperty("app.cmod");
//        if ( cmod == null )
//            cmod = new File( homeFolder,"chartmod").getAbsolutePath();
//
//        Conf.data.put("ChartModule.dir",cmod);
//
//        String smod = getProperty("app.smod");
//
//        if ( smod == null )
//            smod = new File( homeFolder,"searchmod").getAbsolutePath();
//
//        Conf.data.put("SearchModule.dir",smod);
//
//        if ( getProperty("swe.path") == null ) {
//            File file = new File( homeFolder, "ephe" );
//            setProperty("swe.path", file.getAbsolutePath() );
//        }
//    }
    /**
     * プロパティの初期登録を行う。
     * @param regcopy trueならレジストリからConfigにコピー。falseならコピーしない。
     */
    static void setup_regist( boolean regcopy ) {
        System.out.println("home = " + homeFolder.getAbsolutePath());
        if ( ! Config.fileExists() ) {
            // プロパティファイルが存在しないときは新たに作成し初期値を登録
            Config.setDefaultTime( "00:00:00");
            Config.usr.setInteger( "CuspUnknownHouseSystem", 1 );
            Config.usr.setInteger( "HouseSystemIndex",       0 );
            Config.usr.setBoolean( "PrioritizeSolar",     true );
            Config.usr.setBoolean( "UseMeanNode",        false );
            Config.usr.setBoolean( "UseMeanApogee",      false );
            Config.usr.setInteger( "DefaultTimeButtonIndex", 1 );
            Config.usr.setProperty("DefaultTransitPlace",
                     "神奈川県・横浜市西区┃35.453962┃139.617206┃Asia/Tokyo");
            Config.usr.setProperty( "app.topounit",                    "10" );
            Config.usr.setProperty( "app.angleunit",                   "10" );
            Config.usr.setProperty( "AMATERU_ID",     "My name is AMATERU." );
            Config.usr.setProperty( "db.admin.pw",                "amateru" );
            Config.usr.setProperty( "db.plugin.pw",                "plugin" );
            Config.usr.setLong( "AgeOfAmateru",                0L );
            // 本番は.Amateruを指定
            //if ( homeFolder.getAbsolutePath().matches(".*amateru_test$")) {
            if ( regcopy ) {
                try {
                    for ( String key : Conf.data.keys() ) {
                        String val = Conf.data.get(key, "");
                        if ( val.isEmpty() ) continue;
                        Config.usr.setProperty(key, val);
                    }
                    for ( String key : Conf.system.keys() ) {
                        String val = Conf.system.get(key, "");
                        if ( val.isEmpty() ) continue;
                        Config.usr.setProperty(key, val);
                    }
                } catch ( Exception e ) {
                    Logger.getLogger(Initiater.class.getName()).log(Level.WARNING,null,e);
                }
            }
        } else
            Config.load();
        setProperty( "DefaultTime", Config.getDefaultTime());
        setProperty( "app.topounit",
                      Config.usr.getProperty( "app.topounit", "10" ));
        setProperty( "app.angleunit",
                      Config.usr.getProperty( "app.angleunit", "10" ));

        Config.usr.setProperty( "ChartModule.dir", getProperty( "app.cmod",
                new File( homeFolder,"chartmod").getAbsolutePath() ) );
        Config.usr.setProperty( "SearchModule.dir", getProperty( "app.smod",
                new File( homeFolder,"searchmod").getAbsolutePath() ) );

        setProperty( "swe.path",
                      getProperty("swe.path",
                      new File( homeFolder, "ephe" ).getAbsolutePath()) );

        Config.save();
    }
    /**
     * appHomeに/resources/temp.zipを展開して./tempを作成。
     * temp.zipはReportPluginのHTML生成の際に必要なアイコン群。
     * このメソッドは起動するごとにかならず実行。壊しても復元される。
     */
    static void createTempDir() {
        InputStream stream = null;
        byte [] buf = new byte[2048];
        try {
            stream = Initiater.class.getResourceAsStream( "/resources/temp.zip");
            ZipUtils.extract( stream, homeFolder );
        } catch ( Exception e) {
            errorDialog("./tempディレクトリの作成に失敗 " + e.toString());
        } finally {
            try { stream.close(); } catch(Exception e2) { }
        }
    }
    /**
     * サーバ上のupdate.propertyをpropにロードする。
     * @param prop module.propertiesファイルを読みこんだPropertiesオブジェクト。
     */
    static void loadUpdateProperties( Properties prop ) throws IOException {
        URL url = new URL( getProperty("app.lib") + "update.properties");
        FileLoader.loadProp( url, prop );
    }
    /**
     * インストールかアップデートかを識別し、それぞれの処理を呼ぶ。
     */
    static void installOrUpdateFromServer() {
        //キーが存在する場合は一切ファイルをDLしない。テストの時に使う。
        if ( getProperty("app.offline") != null ) return;

        File updateFile = new File( propsFolder, "update.properties" );
        Properties localProp = new Properties();
        if ( updateFile.exists() ) {
            //ローカルにファイルがあるときはインストール済みとみなし更新処理
            try {
                localProp.loadFromXML( new FileInputStream( updateFile ) );
            } catch ( IOException e ) {
                errorDialog("ローカルマシンから更新履歴ファイルの読込に失敗" + e);
                exit();
            }
            updateFromServer(localProp); //サーバから更新をDL
        } else {
            installFromServer();        //サーバからインストール
        }
    }

    /**
     * 新規インストールのときに呼ばれ、サーバーからモジュールやデータをDL。
     * installOrUpdateFromServerから呼び出される。
     */
    static void installFromServer() {
        Properties serverProp = new Properties();
        //サーバからupdate.properteisファイルをDL
        for ( int i=0; i < 3; i++ ) {
            try {
                loadUpdateProperties( serverProp );
                break;
            } catch ( IOException e ) {
                System.out.println("交信失敗" + i + "回目 " + e.toString() );
                if ( i == 2 ) {
                    Logger.getLogger(Initiater.class.getName())
                            .log(Level.SEVERE,null,e);
                    errorDialog( "サーバと通信できません。\n"
                                + "インストールを中止します。");
                    installFailedExit();
                }
            }
        }
        Enumeration<Object> enu;
        for ( enu = serverProp.keys(); enu.hasMoreElements(); ) {
            String key = (String)enu.nextElement();
            if(! key.startsWith("date.")) continue;
            //String server = serverProp.getProperty( key );
            String filename = key.substring(5);
            String name     = serverProp.getProperty(filename);
            String [] temp =
                serverProp.getProperty("download." + filename).split(",");
            String formula = temp[0];
            String cmd = temp[1];
            String path = temp[2];
            File distDir = path.equals(".") ?
                             homeFolder    :    new File( homeFolder, path );
            File tempFile = null;
            URL url = null;
            try {
                tempFile = File.createTempFile("starbase",null);
                tempFile.deleteOnExit();
                url = new URL( getProperty( "app.lib" ) + filename);
                if ( formula.equalsIgnoreCase("basic") ) {
                    FileLoader.load( url, tempFile );
                } else {
                    String mes = String.format(
                        "%sをダウンロードしています。<br>" +
                        "しばらくお待ちください。<br>" +
                        "<font color='red'>中止ボタンを押すとインストールは" +
                        "中断され、インストールは完了しません。</font>",name);
                    int result = DownloadDialog.showDialog(null,url,tempFile,
                        "インストール",
                        name + "をダウンロードしています");
                    if ( result == DownloadDialog.DOWNLOAD_ABORT )
                        throw new Exception("ユーザによる中止");
                    if ( result == DownloadDialog.DOWNLOAD_ERROR )
                        throw new Exception("障害発生");
                }
                if ( cmd.equalsIgnoreCase("extract") ) {
                    ZipUtils.extract(tempFile,distDir);
                } else if ( cmd.equalsIgnoreCase("copy")) {
                    FileLoader.copy( tempFile, new File(distDir,filename));
                } else {
                    throw new java.lang.UnsupportedOperationException(
                        String.format( "\"%s\"という命令はありません。"+
                        "このエラーはサーバサイドの問題で" +
                        "クライアント側の問題ではありません。",cmd) );
                }
            } catch ( Exception e) {
                errorDialog( String.format(
                    "%s のダウンロードに失敗。<br>" +
                    "エラーの詳細 %s<br>" +
                    "インストールできませんでした。終了します。",
                    name,e.toString()));
                installFailedExit();
            }
        }
        saveProp("update.properties",serverProp);
        //インストールのときはプロパティにフラグを立てる。
        //このフラグを検出して、Starbase内では、DBのテーブル作成やアカウントを
        //作成する。
        //setProperty("app.install","true");
    }


    static void updateFromServer( Properties localProp ) {
        System.out.println( "update.propertyにしたがってファイル更新" );
        Properties serverProp = new Properties();
        try {
            loadUpdateProperties( serverProp );
        } catch ( IOException e ) {
            System.out.println( "サーバーと通信できません。"
                              + "更新作業はまた次の機会に。");
            Logger.getLogger(Initiater.class.getName())
                    .log(Level.SEVERE,null,e );
            return;
        }
        System.out.println("update.propertyにしたがってファイル更新中");
        Enumeration<Object> enu;
        for ( enu = serverProp.keys(); enu.hasMoreElements(); ) {
            String key = (String)enu.nextElement();
            if (! key.startsWith("date.")) continue;
            String local = localProp.getProperty( key );
            if ( local == null ) local = "";
            String server = serverProp.getProperty( key );
            if ( local.equals(server) ) continue;
            String filename = key.substring(5);
            String name     = serverProp.getProperty(filename);
            String [] temp =
                serverProp.getProperty("download." + filename).split(",");
            String formula = temp[0];
            String cmd = temp[1];
            String path = temp[2];
            File distFile = path.equals(".") ?
                      homeFolder    :    new File( homeFolder, path );
            File tempFile = null;
            URL url = null;
            try {
                tempFile = File.createTempFile("starbase",null);
                tempFile.deleteOnExit();
                url = new URL( getProperty("app.lib") + filename );
                if ( formula.equalsIgnoreCase("basic") ) {
                    FileLoader.load(url,tempFile);
                } else {
                    int result = DownloadDialog.showDialog(null,url,tempFile,
                        "アップデート",
                        name + "をダウンロードしています。");
                    if ( result == DownloadDialog.DOWNLOAD_ABORT )
                        continue;
                    if( result == DownloadDialog.DOWNLOAD_ERROR ) {
                        errorDialog(
                            "通信障害が発生したようです。<br>" +
                            "アップデートはまた次回の起動時に行います。");
                        break;
                    }
                }
                if ( cmd.equalsIgnoreCase("extract") ) {
                    ZipUtils.extract( tempFile, distFile );
                } else if ( cmd.equalsIgnoreCase("copy")) {
                    if ( distFile.isDirectory() )
                        distFile = new File( distFile, filename );
                    FileLoader.copy( tempFile, distFile );
                } else {
                    throw new java.lang.UnsupportedOperationException(
                        String.format( "\"%s\"という命令はありません。"+
                        "このエラーはサーバサイドの問題で" +
                        "クライアント側の問題ではありません。",cmd) );
                }
                String dateKey = "date." + filename;
                String downKey = "download." + filename;
                localProp.setProperty( dateKey, serverProp.getProperty( dateKey ) );
                localProp.setProperty( downKey, serverProp.getProperty( downKey ) );
                localProp.setProperty( filename,serverProp.getProperty( filename ) );
            } catch ( Exception e) {
                errorDialog( String.format("%sのダウンロードに失敗。<br>" +
                    "エラーの詳細 %s", name, e.toString() ) );
            }
        }
        saveProp( "update.properties", localProp );
    }

    private static int MUTEX_PORT = 12399;
    private static SingleInstanceService sis = null;
    private static SingleInstanceListener sil = null;

    private static void exit() {
        if ( sis != null )
            sis.removeSingleInstanceListener(sil);
        System.exit(0);
    }
    /**
     * インストールに失敗したときは、作成した.Amateruのファイルを削除して
     * 終了。
     */
    private static void installFailedExit() {
        if ( sis != null )
            sis.removeSingleInstanceListener(sil);
        if ( homeFolder.exists() ) {
            String homeName = getProperty("app.home.name");
            if ( homeName == null) {
                ZipUtils.rmdirs( homeFolder, ".Amateru" );
            } else {
                // app.homeを外部から指定されている場合。テスト時に呼ばれうる。
                ZipUtils.rmdirs( homeFolder, homeName );
            }
        }
        System.exit( 0 );
    }
    /**
     * Systemプロパティに設定可能なキー
     * "app.home"   user.homeの下に作成されるapp.homeの名前。デフォルトだと
     * .Amateruになるが、テストの時などには明示的に指定することもできる。
     */
    public static void main(String [] args)
                                    throws java.net.MalformedURLException {
        StopWatch.set("StartupTime");
        System.out.println("■実行開始");

        /* JWSのJNLPファイルから引き渡せるプロパティは、"javaws."で始まる名前で
           なければならない。それを受け取ったら名前から"javaws."を取り去り保管 */

        //app.libの検査と調整

        if ( getProperty("javaws.app.lib") != null )
            setProperty("app.lib", getProperty("javaws.app.lib"));
        String url = getProperty( "app.lib" );
        if ( url == null ) {
            Logger.getLogger(Initiater.class.getName())
                    .log(Level.INFO,"app.libを指定してください。" );
            System.exit(1);
        }
        if ( ! url.endsWith( "/" )  ) url = url + "/";
        setProperty( "app.lib", url );

        //app.homeの検査と調整

        if ( getProperty("javaws.app.home.name") != null )
            setProperty( "app.home.name", getProperty("javaws.app.home.name"));

        //.Amateruフォルダを指すFileオブジェクトを作る
        if ( getProperty( "app.home" ) == null ) {
            String homeName = getProperty("app.home.name");
            homeFolder = new File( getProperty("user.home"),
                                 ( homeName == null ) ? ".Amateru" : homeName );
            setProperty( "app.home", homeFolder.getAbsolutePath() );
        } else {
            homeFolder = new File( getProperty( "app.home" ) );
        }

        //.Amateru/properties/フォルダを指すFileオブジェクトを作る
        propsFolder = new File( homeFolder, "properties" );


        // LookAndFeelの設定
        java.awt.EventQueue.invokeLater( new LookAndFeel() );

        /* Java Web Startからの起動かそうでないかを検出してフラグを立てる
           Java Web Startの場合、リスナを登録して多重起動抑止を有効にする。 */

        boolean jws_activated = false; //フラグ
        try {
            sis = (SingleInstanceService)ServiceManager
                .lookup("javax.jnlp.SingleInstanceService");
            sil = new SingleInstanceListener() {
                @Override
                public void newActivation(String[] string) {
                    System.out.println("多重起動を検出");
                }
            };
            sis.addSingleInstanceListener(sil);
            jws_activated = true;
        } catch ( Exception e ) {
            sil = null;
        }
        System.out.println("Java Web Start Activated : " + jws_activated );
        if ( ! jws_activated ) {
            if ( MutexServer.isRunning( MUTEX_PORT ) ) {
                System.out.println("すでに動作中です。");
                exit();
            }
        }
        boolean regcopy = true;
        if ( ! homeFolder.exists() ) {
            propsFolder.mkdirs();
            new File( homeFolder, "chartmod").mkdir();
            new File( homeFolder, "searchmod").mkdir();
            //　ホームフォルダを新規に作った場合、レジストリの引き継ぎはしない。
            // ホームフォルダが残っていた場合は引き継ぐ
            regcopy = false;
        }

        setup_regist( regcopy );
        createTempDir();
        installOrUpdateFromServer();
        Starbase.exec( sis, sil );
    }

    private static class LookAndFeel implements Runnable {
        @Override
        public void run() {
            UIManager.put("swing.boldMetal", Boolean.FALSE);
        }
    }
//            try {
//                UIManager.setLookAndFeel(
//                        "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
//                JDialog.setDefaultLookAndFeelDecorated(true);
//                JFrame.setDefaultLookAndFeelDecorated(true);
//            } catch ( Exception e ) {
//                e.printStackTrace();
//            }
//            if(! UIManager.getLookAndFeel().getName().equals("Metal")) return;
//
//            //            try {
//                UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
//                //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            UIManager.put("swing.boldMetal", Boolean.FALSE);
////            FontUIResource font = new FontUIResource(
////                new Font("Dialog",Font.PLAIN,10));
////            UIManager.put("Button.font",font);
////            UIManager.put("ToggleButton.font",font);
////            UIManager.put("PopupMenu.font",font);
////            UIManager.put("Menu.font",font);
////            UIManager.put("MenuItem.font",font);
////            UIManager.put("MenuBar.font",font);
//            //JDialog.setDefaultLookAndFeelDecorated(true);
//            //JFrame.setDefaultLookAndFeelDecorated(true);
//            Toolkit.getDefaultToolkit().setDynamicLayout(true);
//        }
//    }
}
