/*
 * Config2.java
 *
 * Created on 2007/02/13, 7:03
 *
 * このクラスは廃止予定。
 */

package to.tetramorph.starbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import to.tetramorph.starbase.lib.Home;
import to.tetramorph.util.Preference;

/**
 * スターベースの各種プロパティを保管するための不揮発性Preference。
 * Runtimeのシャットダウンフックに、データセーブの処理を登録してるので、
 * システム終了時に自動的にファイルにデータは保管される。
 * なおプロパティファイルがロードされるタイミングは、このクラスを始めに使用
 * したときで、もし一度も使用しなければ、ロードは行われない。
 * <pre>
 * プロパティファイルの保管場所
 *  dataFile = new File(Home.properties,"Config2.properties");
 *  systemFile = new File(Home.properties,"System.properties");
 *
 * 使い方
 *   Config2.data.getProperty("hogehoge");
 *   Config2.data.setColor("BGColor",Color.BLACK);
 * </pre>
 */
final class Config2 {
    /**
     * 使用ノードタイプやハウス分割法などユーザの設定保管用
     */
    public static Preference data = new Preference();
    /**
     * GUIの状態保存などシステムよりの情報保管用。
     */
    public static Preference system = new Preference();

    private static File dataFile;
    private static File systemFile;
    // インスタンス作成禁止
    private Config2() {}

    // クラスロード時にプロパティファイルを読みこむ。
    // プロパティファイルからの読み込みと保存は自動で行われるので、
    // プログラマは気にしなくて良い。
    static {

        dataFile = new File( Home.properties,"Config.properties" );
        load(dataFile,data);

        systemFile = new File( Home.properties,"System.properties" );
        load( systemFile, system );

        //シャットダウンのときにファイルを保存 *1
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                if ( ! data.isEmpty() )
                    save( dataFile, data );
                if ( ! system.isEmpty() )
                    save(systemFile,system);
            }
        });
    }
    // *1
    // 時々Config.propertiesの内容が空になってしまうことがある。空のProeprties
    // をファイルに書き出した状態。いつそういう事態が発生するのか、完全にしぼり
    // こめていないのだが、ファイルに保存する操作は、シャットダウンフックの中
    // だけなので、対処療法だがここに安全装置を用意している。つまり、内容が空
    // のPropertiesはセーブしないようにしている。

    // データロード。
    private static void load( File file, Preference pref ) {
        if ( file.exists() ) {
            FileInputStream stream = null;
            try {
                stream = new FileInputStream(file);
                pref.loadFromXML(stream);
            } catch ( IOException e ) {
                e.printStackTrace();
            } finally {
                try {
                    stream.close();
                } catch ( Exception e ) { }
            }
        }
    }
    // データをセーブ。
    private static void save( File file, Preference pref ) {
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream( file );
            pref.storeToXML( stream, "エディタ等で編集しないでください" );
            //System.out.println("\"" + file.toString() + "\" Saved.");
        } catch ( IOException e ) {
            e.printStackTrace();
        } finally {
            try { stream.close(); } catch ( Exception e ) { }
        }
    }
}
