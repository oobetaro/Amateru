/*
 * OSType.java
 * Created on 2011/07/27, 20:40:08.
 */
package amateru_uninstaller;
import static java.lang.System.getProperty;
/**
 *
 * @author ohsawa
 */
public class OSType {
    /**
     * このプログラムが実行されているOSの系統を返す。
     * "windows","mac","unix"の三種類のみ。
     * @return
     */
    public static String getName() {
        String os = getProperty("os.name","");
        if ( os.matches("^Windows.*") ) {
            return "Windows";
        } else if ( os.toLowerCase().matches("^mac os")) {            // Mac
            return "Mac OS";
        }
        return "Unix";
    }
    /**
     * @return OSがWindowsならtrueを返す。
     */
    public static boolean isWindows() {
        return getProperty("os.name").toLowerCase().indexOf("windows") >= 0;
    }
    /**
     * @return OSがMacならtrueを返す。
     */
    public static boolean isMac() {
        return getProperty("os.name").toLowerCase().indexOf("mac") >= 0;
    }
    /**
     * @return OSがUnixならtrueを返す。だが実際のところはウインドウズでもマック
     * でもなければすべてUnixとみなしているだけ。
     */
    public static boolean isUnix() {
        return ! isWindows() && ! isMac();
    }
}
